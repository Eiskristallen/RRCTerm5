from setuptools import setup
setup(
    name="IPScraper",
    version="1.0",
    description="Scrape my ip address.",
    author="Your Name",
    author_email="name@domain.com",
    py_modules=["ipscraper"],
)
